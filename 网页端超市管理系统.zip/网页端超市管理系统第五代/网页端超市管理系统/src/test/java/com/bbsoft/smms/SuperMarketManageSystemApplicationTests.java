package com.bbsoft.smms;

import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.domain.User;
import com.bbsoft.smms.service.CommodityService;
import com.bbsoft.smms.service.UserService;
import com.bbsoft.smms.service.WareService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SuperMarketManageSystemApplicationTests {

    @Autowired
    CommodityService commodityService;
    @Autowired
    WareService wareService;

	@Test
	public void contextLoads() {
	    System.setProperty("java.awt.headless","false");
	}

	@Test
	public void test1(){
	    commodityService.list_num().forEach(System.out::println);
    }

    @Test
    public void test2(){

    }

    @Autowired
    UserService userService;

    @Test
    public void test3(){
        User user = new User(39,"admin2","123456");
        user.setIdentify("manager");
        user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
        userService.new_user(user);
    }
}
