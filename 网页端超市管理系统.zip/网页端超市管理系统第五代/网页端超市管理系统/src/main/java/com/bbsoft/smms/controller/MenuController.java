package com.bbsoft.smms.controller;

import com.bbsoft.smms.APIService.APIService;
import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.domain.User;
import com.bbsoft.smms.domain.Ware;
import com.bbsoft.smms.service.CommodityService;
import com.bbsoft.smms.service.UserService;
import com.bbsoft.smms.service.WareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

@Controller
public class MenuController {

    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    WareService wareService;
    @Autowired
    APIService apiService;

    @RequestMapping(value = "/login",method = RequestMethod.GET)
    public void login(){}
    @RequestMapping(value = "/userEnter",method = RequestMethod.GET)
    public void userEnter(){}
    @RequestMapping(value = "/userEnter1",method = RequestMethod.GET)
    public void userEnter1(){}
    @RequestMapping(value = "/userEnter2",method = RequestMethod.GET)
    public void userEnter2(){}
    @RequestMapping(value = "/userEnter3",method = RequestMethod.GET)
    public void userEnter3(){}
    @RequestMapping(value = "/ManagerMenu",method = RequestMethod.GET)
    public String Menu(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        List<Ware>wares=wareService.list_num();
        String name="";
        String num="";
        for(int i=0;i<list.size()-1;i++){
            num+=wares.get(i).getTotal_volume()+"#";
            name+=list.get(i).getName()+"#";
        }
        num+=wares.get(list.size()-1).getTotal_volume();
        name+=list.get(list.size()-1).getName();
        apiService.setCookie(request,response,"goodsNum",num);
        apiService.setCookie(request,response,"goodsName",name);
        return "/ManagerMenu";
    }
    @RequestMapping(value = "/SellerMenu",method = RequestMethod.GET)
    public List<Commodity> sellerMenu(HttpServletRequest  request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getRemain()+"#";
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        sell+=list.get(list.size()-1).getRemain();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsRemain",sell);
        return commodityService.list_num();
    }
    @RequestMapping(value = "/BuyerMenu",method = RequestMethod.GET)
    public List<Commodity> buyerMenu(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getRemain()+"#";
            name+=list.get(i).getName()+"#";
        }
        sell+=list.get(list.size()-1).getRemain();
        name+=list.get(list.size()-1).getName();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsRemain",sell);
        return commodityService.list_num();
    }
    @RequestMapping(value = "/MenuGoods",method = RequestMethod.GET)
    public String MenuGoods(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getVolume()+"#";
            name+=list.get(i).getName()+"#";
        }
        sell+=list.get(list.size()-1).getVolume();
        name+=list.get(list.size()-1).getName();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsVolume",sell);
        return "/MenuGoods";
    }
    @RequestMapping(value = "/MenuWare",method = RequestMethod.GET)
    public String MenuWare(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Ware>list=wareService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getTotal_benefit()+"#";
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        sell+=list.get(list.size()-1).getTotal_benefit();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsTBenefit",sell);
        return "/MenuWare";
    }
    @RequestMapping(value = "/MenuUser",method = RequestMethod.GET)
    public List<User> MenuUser(){
        return userService.listAll();
    }

}
