package com.bbsoft.smms.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .formLogin()
                    .loginPage("/login")
                    .defaultSuccessUrl("/userEnter")
                    .permitAll()
                .and()
                .authorizeRequests()
                    .antMatchers("/","/register","/js/**","/css/**","/pic/**").permitAll()
                    .antMatchers("/Register").permitAll()
                    .antMatchers("/home").permitAll()
                    .antMatchers("/ManagerMenu").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Amenduser").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Amendware").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Buyer_Commodities_add").access("hasAnyAuthority('manager') or hasAnyAuthority('buyer') or hasAnyAuthority('boss')" )
                    .antMatchers("/Buyer_Commodities_list_num").access("hasAnyAuthority('manager') or hasAnyAuthority('buyer') or hasAnyAuthority('boss')")
                    .antMatchers("/Buyer_Commodities_SearchById").access("hasAnyAuthority('manager') or hasAnyAuthority('buyer') or hasAnyAuthority('boss')")
                    .antMatchers("/BuyerMenu").access("hasAnyAuthority('manager') or hasAnyAuthority('buyer') or hasAnyAuthority('boss')")
                    .antMatchers("/SellerMenu").access("hasAnyAuthority('manager') or hasAnyAuthority('seller') or hasAnyAuthority('boss')")
                    .antMatchers("/Commodities_list_num").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Commodities_list_volume").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Commodities_list_gross").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Commodities_SearchById").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/commodity").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/commodity_Seller").access("hasAnyAuthority('manager') or hasAnyAuthority('boss') or hasAnyAuthority('seller')")
                    .antMatchers("/commodity_Buyer").access("hasAnyAuthority('manager') or hasAnyAuthority('boss') or hasAnyAuthority('buyer')")
                    .antMatchers("/MenuUser").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/MenuGoods").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/MenuWare").hasAuthority("boss")
                    .antMatchers("/Seller_Commodities_add").access("hasAnyAuthority('manager') or hasAnyAuthority('seller') or hasAnyAuthority('boss')")
                    .antMatchers("/Seller_Commodities_list_num").permitAll()
                    .antMatchers("/Seller_Commodities_SearchById").permitAll()
                    .antMatchers("/user").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Users_DeleteNum").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Users_list_num").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Users_SearchById").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/UsersAmendById").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Users_add").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/ware").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/ware_list_num").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Wares_add").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Wares_DeleteNum").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Wares_list_gross").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Wares_list_volume").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/Wares_SearchById").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .antMatchers("/WaresAmendById").access("hasAnyAuthority('manager') or hasAnyAuthority('boss')")
                    .anyRequest().authenticated();
        http.csrf().disable();
    }

    @Autowired
    AUserDetailsService userDetailsService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService)
                .passwordEncoder(new BCryptPasswordEncoder());
    }
}
