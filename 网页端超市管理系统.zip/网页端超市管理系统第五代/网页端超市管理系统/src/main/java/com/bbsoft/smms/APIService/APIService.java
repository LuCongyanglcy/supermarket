package com.bbsoft.smms.APIService;


import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

public interface APIService {

    String getCookie(HttpServletRequest request, HttpServletResponse response, String cname) throws UnsupportedEncodingException;

    void setCookie(HttpServletRequest request, HttpServletResponse response, String cname, String cvalue) throws UnsupportedEncodingException;

    void deleteCookie(HttpServletResponse response, String cname);

    List<String> divideYourAnswerLittle(String stringList);

    List<String> divideYourAnswerLittle(String stringList, String symbol);

    void  download(HttpServletRequest request, HttpServletResponse response, String filePath);

}
