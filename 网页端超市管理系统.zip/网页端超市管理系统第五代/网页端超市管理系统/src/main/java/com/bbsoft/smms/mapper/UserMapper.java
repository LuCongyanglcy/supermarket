package com.bbsoft.smms.mapper;

import com.bbsoft.smms.domain.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {

    List<User>index(String username);

    List<User>listAll();

    List<User>searchId(int id);

    void amendId(@Param("id")int id,@Param("user")User user);

    List<User> verify(User user);

    List<User> verify_protection(User user);

    void new_user(User user);

    void delete(int id);
}
