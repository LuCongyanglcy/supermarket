package com.bbsoft.smms.service;

import com.bbsoft.smms.domain.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserService {

    List<User>index(String username);

    List<User>listAll();

    List<User>searchId(int id);

    void amendId(int id, User user);

    List<User> verify(User user);

    List<User> verify_protection(User user);

    void new_user(User user);

    void delete(int id);
}
