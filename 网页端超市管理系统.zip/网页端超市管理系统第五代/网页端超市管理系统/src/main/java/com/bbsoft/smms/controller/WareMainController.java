package com.bbsoft.smms.controller;

import com.bbsoft.smms.APIService.APIService;
import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.domain.Ware;
import com.bbsoft.smms.service.CommodityService;
import com.bbsoft.smms.service.UserService;
import com.bbsoft.smms.service.WareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Scanner;

@Controller
public class WareMainController {

    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    WareService wareService;
    @Autowired
    APIService apiService;


    @RequestMapping(value = "/ware_list_num",method = RequestMethod.GET)
    public List<Ware> ware_list_num(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
        List<Ware>list=wareService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getTotal_sell()+"#";
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        sell+=list.get(list.size()-1).getTotal_sell();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsTSell",sell);
        return wareService.list_num();
    }
    @RequestMapping(value = "/Wares_list_volume",method = RequestMethod.GET)
    public List<Ware> Wares_list_volume(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Ware>list=wareService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getTotal_volume()+"#";
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        sell+=list.get(list.size()-1).getTotal_volume();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsTVolume",sell);
        return wareService.list_volume();
    }
    @RequestMapping(value = "/Wares_list_gross",method = RequestMethod.GET)
    public List<Ware> Wares_list_gross(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Ware>list=wareService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getTotal_benefit()+"#";
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        sell+=list.get(list.size()-1).getTotal_benefit();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsTBenefit",sell);
        return wareService.list_gross();
    }
    @RequestMapping(value = "WareDeleteAll",method = RequestMethod.GET)
    public String WareDeleteAll(){
        wareService.delete_all();
        commodityService.delete_all();
        return "MenuWare";
    }

    @RequestMapping(value = "/Wares_add",method = RequestMethod.GET)
    public String Wares_add_form(){
        return "Wares_add";
    }
    @RequestMapping(value ="/Wares_add", method = RequestMethod.POST)
    public String Wares_add(Ware form) {
        if(!wareService.listAll(form.getNum()).isEmpty())
            return "ErrorRepeatNum";
        form.setTotal_cost();
        form.setTotal_volume();
        form.setTotal_benefit();
        wareService.add(form);
        Commodity commodity=new Commodity();
        commodity.setNum(form.getNum());
        commodity.setName(form.getName());
        commodity.setKind(form.getKind());
        commodity.setBid(form.getBid());
        commodity.setPrice(form.getPrice());
        commodity.setStock(form.getTotal_stock());
        commodity.setSell(form.getTotal_sell());
        commodity.setVolume();
        commodity.setRemain(form.getTotal_stock()-form.getTotal_sell());
        commodity.setGross();
        commodityService.add(commodity);
        return  "redirect:/ware";
    }
    @RequestMapping(value = "/ware" ,method = RequestMethod.GET)
    public String Return_Wares_add(){
        return "Wares_add";
    }

    @RequestMapping(value = "/Wares_SearchById",method = RequestMethod.GET)
    public String searchById(@RequestParam(value = "num",defaultValue = "0") int num,Model model){
        if (num==0)
            return "Wares_SearchById";
        if(wareService.listAll(num).isEmpty())
            return  "Wares_SearchById";
        Ware ware=wareService.listAll(num).get(0);
        model.addAttribute(ware);
        return "ware";
    }

    @RequestMapping(value = "/WaresAmendById",method = RequestMethod.GET)
    public  String AmendByIdForm(@RequestParam(value = "num",defaultValue = "0")int num,Model model){
        if(num==0)
            return "WaresAmendById";
        if(wareService.listAll(num).isEmpty())
            return  "WaresAmendById";
        Ware ware=wareService.listAll(num).get(0);
        model.addAttribute(ware);
        return "Amendware";
    }
    @RequestMapping(value = "/Amendware",method = RequestMethod.POST)
    public String amendById(int num, Ware ware){
        ware.setTotal_cost();
        ware.setTotal_volume();
        ware.setTotal_benefit();
        wareService.amend_num(num,ware);
        Commodity commodity=new Commodity();
        commodity.setNum(ware.getNum());
        commodity.setName(ware.getName());
        commodity.setKind(ware.getKind());
        commodity.setBid(ware.getBid());
        commodity.setPrice(ware.getPrice());
        commodity.setStock(commodity.getStock());
        commodity.setSell(commodity.getSell());
        commodity.setVolume();
        commodity.setRemain(ware.getTotal_stock()-ware.getTotal_sell());
        commodity.setGross();
        commodityService.amend_num(num,commodity);
        return "Amendware";
    }
    @RequestMapping(value = "/Amendware",method = RequestMethod.GET)
    public String AmendWare(){
        return "WaresAmendById";
    }

    @RequestMapping(value ="/Wares_DeleteNum",method = RequestMethod.GET)
    public String Wares_DeleteNumForm(@RequestParam(value = "num",defaultValue = "0")int num,Model model){
        if(num==0)
            return "Wares_DeleteNum";
        Ware ware=wareService.listAll(num).get(0);
        model.addAttribute(ware);
        return "Wares_DeleteNum";
    }
    @RequestMapping(value = "/Wares_DeleteNum",method = RequestMethod.POST)
    public String Wares_DeleteNum(int num){
        wareService.delete_num(num);
        commodityService.delete_num(num);
        return "redirect:/Ware";
    }
    @RequestMapping(value = "/Ware",method = RequestMethod.GET)
    public String Delete_Num(){
        return "Wares_DeleteNum";
    }

}
