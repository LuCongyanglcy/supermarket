package com.bbsoft.smms.service;

import com.bbsoft.smms.domain.Ware;

import java.util.List;

public interface WareService {

    void delete_all();               //prepare insert

    List<Ware>listAll(int num);

    List<Ware> list_num();

    List<Ware> list_volume();              //Information display

    List<Ware> list_gross();


    void add(Ware ware);

    void delete_num(int num);

    void delete_name(String name);

    void amend_num(int number, Ware ware);



    List<Ware> search_num(int num);

    List<Ware> search_name(String name);
}
