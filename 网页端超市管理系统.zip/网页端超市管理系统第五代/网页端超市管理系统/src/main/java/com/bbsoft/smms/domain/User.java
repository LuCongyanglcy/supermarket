package com.bbsoft.smms.domain;

import com.bbsoft.smms.service.UserService;

import java.util.List;

public class User {
    private int id;
    private  String username;
    private String password;
    private String secret_protection;
    private  String identify;

    public User(){}

    public User(int id, String username, String password) {
        this.id = id;
        this.password = password;
        this.username=username;
    }
    public User(int id, String username, String secret_protection, String identify) {
        this.id = id;
        this.username = username;
        this.secret_protection =secret_protection;
        this.identify=identify;
    }
    public User(int id, String username, String password, String secret_protection, String identify)
    {
        this.id = id;
        this.username = username;
        this.password = password;
        this.secret_protection =secret_protection;
        this.identify=identify;
    }
    public User (String username,String identify)
    {
        this.username=username;
        this.identify=identify;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSecret_protection() { return secret_protection; }

    public void setSecret_protection(String secret_protection) { this.secret_protection = secret_protection; }

    public String getIdentify() { return identify; }

    public void setIdentify(String identify) { this.identify = identify; }

    @Override
    public String toString() {
        return String.format("id:%d, 用户名%s, password:%s, secret_protection:%s,身份%s",id,username,password,secret_protection,identify);
    }
}
