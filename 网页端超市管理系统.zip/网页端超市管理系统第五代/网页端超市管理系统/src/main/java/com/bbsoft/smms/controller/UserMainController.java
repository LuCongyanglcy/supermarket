package com.bbsoft.smms.controller;

import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.domain.User;
import com.bbsoft.smms.service.CommodityService;
import com.bbsoft.smms.service.UserService;
import com.bbsoft.smms.service.WareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class UserMainController {

    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    WareService wareService;

    @RequestMapping(value = "/Users_list_num",method = RequestMethod.GET)
    public List<User> Users_list_num(){
        return userService.listAll();
    }

    @RequestMapping(value = "/Users_add",method = RequestMethod.GET)
    public String Users_add_form(){
        return "Users_add";
    }
    @RequestMapping(value ="/Users_add", method = RequestMethod.POST)
    public String Users_add(User form) {
        if(!userService.index(form.getUsername()).isEmpty())
            return "ErrorRepeatName";
        form.setPassword(new BCryptPasswordEncoder().encode(form.getPassword()));
        userService.new_user(form);
        return  "redirect:/user";
    }
    @RequestMapping(value = "/user" ,method = RequestMethod.GET)
    public String Return_Users_add(){
        return "Users_add";
    }

    @RequestMapping(value = "Register",method = RequestMethod.GET)
    public String registerForm(){return "Register";}
    @RequestMapping(value = "Register",method = RequestMethod.POST)
    public String register(User user){
        if(!userService.index(user.getUsername()).isEmpty()&&!user.getUsername().equals("0"))
            return "/RegisterErrorRepeatName";
        if(user.getUsername().equals("0"))
            return "/Register";
        user.setIdentify("domestic consumer");
        user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
        userService.new_user(user);
        return "RegisterSuccessfully";
    }

    @RequestMapping(value = "/Users_SearchById",method = RequestMethod.GET)
    public String searchById(@RequestParam(value = "id",defaultValue = "0") int id, Model model){
        if (id==0)
            return "Users_SearchById";
        if(userService.searchId(id).isEmpty())
            return "Users_SearchById";
        User user=userService.searchId(id).get(0);
        model.addAttribute(user);
        return "user";
    }

    @RequestMapping(value = "/UsersAmendById",method = RequestMethod.GET)
    public  String AmendByIdForm(@RequestParam(value = "id",defaultValue = "0")int id,Model model){
        if(id==0)
            return "UsersAmendById";
        if(userService.searchId(id).isEmpty())
            return "UsersAmendById";
        User user=userService.searchId(id).get(0);
        model.addAttribute(user);
        return "Amenduser";
    }
    @RequestMapping(value = "/Amenduser",method = RequestMethod.POST)
    public String amendById(int id,User user){
        userService.amendId(id,user);
        return "Amenduser";
    }
    @RequestMapping(value = "/Amenduser",method = RequestMethod.GET)
    public String Amenduser(){
        return "UsersAmendById";
    }

    @RequestMapping(value ="/Users_DeleteNum",method = RequestMethod.GET)
    public String Users_DeleteNumForm(@RequestParam(value = "id",defaultValue = "0")int id,Model model){
        if(id==0)
            return "Users_DeleteNum";
        User user=userService.searchId(id).get(0);
        model.addAttribute(user);
        return "Users_DeleteNum";
    }
    @RequestMapping(value = "/Users_DeleteNum",method = RequestMethod.POST)
    public String Users_DeleteNum(int id){
        userService.delete(id);
        return "redirect:/User";
    }
    @RequestMapping(value = "/User",method = RequestMethod.GET)
    public String Delete_Num(){
        return "Users_DeleteNum";
    }

}
