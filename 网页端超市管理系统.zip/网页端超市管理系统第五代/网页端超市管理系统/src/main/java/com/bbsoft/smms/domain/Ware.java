package com.bbsoft.smms.domain;

public class Ware {
    private int num;
    private String name;
    private String kind;
    private float bid;
    private float price;
    private String manufacturer;//生产商
    private int total_stock;//总进货量
    private int total_sell;//总销售量
    private float total_cost;   //总成本
    private float total_volume;//总销售额
    private float total_benefit;//总利润

    public Ware(){}
    public Ware(int num, String name, String kind, float bid, float price, String manufacturer, int total_stock, int total_sell, float total_cost, float total_volume, float total_benefit)
    {
        this.num=num;
        this.name = name;
        this.kind=kind;
        this.bid=bid;
        this.price=price;
        this.manufacturer=manufacturer;
        this.total_stock=total_stock;
        this.total_sell=total_sell;
        this.total_cost=total_cost;
        this.total_volume=total_volume;
        this.total_benefit=total_benefit;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public float getBid() {
        return bid;
    }

    public void setBid(float bid) {
        this.bid = bid;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getTotal_stock() {
        return total_stock;
    }

    public void setTotal_stock(int total_stock) {
        this.total_stock = total_stock;
    }

    public int getTotal_sell() {
        return total_sell;
    }

    public void setTotal_sell(int total_sell) {
        this.total_sell = total_sell;
    }

    public float getTotal_cost() {
        return this.total_sell*this.bid;
    }

    public void setTotal_cost() {
        this.total_cost = this.total_sell*this.bid;
    }

    public float getTotal_volume() {
        return this.price*this.total_sell;
    }

    public void setTotal_volume() {
        this.total_volume=this.price*this.total_sell;
    }

    public float getTotal_benefit() {
        return (this.price-this.bid)*this.total_sell;
    }

    public void setTotal_benefit() {
        this.total_benefit = this.total_volume-this.total_cost;
    }

    @Override
    public String toString() {
        return String.format("编号%d, name:%s, kind:%s,bid:%f,price:%f,manufacturer=%s,total_stock=%d,total_sell=%d,total_cost=%f,total_volume=%f,total_benefit=%f", num, name, kind, bid, price, manufacturer, total_stock, total_sell, total_cost, total_volume, total_benefit);
    }
}
