package com.bbsoft.smms.APIService.APIServiceImpl;

import com.bbsoft.smms.APIService.APIService;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@Service
public class APIServiceImpl implements APIService{



    @Override
    public String getCookie(HttpServletRequest request, HttpServletResponse response,String cname) throws UnsupportedEncodingException {
        Cookie[] cookies=request.getCookies();
        String str="";
        for(int i=0;i<cookies.length;i++){
            Cookie cookie=cookies[i];
            if(cookie.getName().equals(cname)) {
                str = URLDecoder.decode(cookie.getValue(),"UTF-8");
                break;
            }
        }
        return str;
    }

    @Override
    public void setCookie(HttpServletRequest request, HttpServletResponse response,String cname,String cvalue) throws UnsupportedEncodingException {
        Cookie cookie=new Cookie(cname, URLEncoder.encode(cvalue,"utf-8"));
        response.addCookie(cookie);
    }

    @Override
    public void deleteCookie(HttpServletResponse response,String cname){
        Cookie cookie=new Cookie("str","");
        cookie.setMaxAge(0);
        response.addCookie(cookie);
    }

    @Override
    public List<String> divideYourAnswerLittle(String stringList) {
        String b = " ,，;；+=";
        return divideYourAnswerLittle(stringList,b);
    }

    private static boolean panand(String b, char a) {
        for (int i = 0; i < b.length(); i++) {
            if (b.charAt(i) == a) return false;
        }
        return true;
    }

    @Override
    public List<String> divideYourAnswerLittle(String stringList, String symbol) {
        List<String> strings = new LinkedList<>();
        String c = "";
        for (int j = 0; j < stringList.length(); j++) {
            if (panand(symbol, stringList.charAt(j)))
                c += stringList.charAt(j);
            if (!panand(symbol, stringList.charAt(j)) || j + 1 == stringList.length()) {
                strings.add(c);
                c = "";
            }
        }
        return strings;
    }

    @Override
    public void  download(HttpServletRequest request, HttpServletResponse response,String filePath){
        response.setCharacterEncoding(request.getCharacterEncoding());
        response.setContentType("application/octet-stream");
        FileInputStream fis = null;
        try {
            File file = new File(filePath);
            fis = new FileInputStream( file);
            response.setHeader("Content-Disposition", "attachment; filename="+file.getName());
            IOUtils.copy(fis,response.getOutputStream());
            response.flushBuffer();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


}
