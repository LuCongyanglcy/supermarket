package com.bbsoft.smms.controller;

import com.bbsoft.smms.APIService.APIService;
import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.domain.Ware;
import com.bbsoft.smms.service.CommodityService;
import com.bbsoft.smms.service.UserService;
import com.bbsoft.smms.service.WareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Scanner;

@Controller
public class CommodityMainController {

    @Autowired
    CommodityService commodityService;
    @Autowired
    UserService userService;
    @Autowired
    WareService wareService;
    @Autowired
    APIService apiService;


    @RequestMapping(value = "/")
    public String home(){
        return "login";
    }

    @RequestMapping(value = "/home",method = RequestMethod.GET)
    public void homepage(){}
    @RequestMapping(value = "/Commodities_list_num",method = RequestMethod.GET)
    public List<Commodity> Commodities_list_num(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getSell()+"#";
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        sell+=list.get(list.size()-1).getSell();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsSell",sell);
        return commodityService.list_num();
    }
    @RequestMapping(value = "/Seller_Commodities_list_num",method = RequestMethod.GET)
    public List<Commodity> Seller_Commodities_list_num(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getPrice()+"#";
            name+=list.get(i).getName()+"#";
        }
        sell+=list.get(list.size()-1).getPrice();
        name+=list.get(list.size()-1).getName();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsPrice",sell);
        return commodityService.list_num();
    }
    @RequestMapping(value = "/Buyer_Commodities_list_num",method = RequestMethod.GET)
    public List<Commodity> buyer_Commodities_list_num(HttpServletResponse response,HttpServletRequest request) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getSell()+"#";
            name+=list.get(i).getName()+"#";
        }
        sell+=list.get(list.size()-1).getSell();
        name+=list.get(list.size()-1).getName();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsSell",sell);
        return commodityService.list_num();
    }
    @RequestMapping(value = "/Commodities_list_volume",method = RequestMethod.GET)
    public List<Commodity> Commodities_list_volume(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String volume="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            name+=list.get(i).getName()+"#";
            volume+=list.get(i).getVolume()+"#";
        }
        name+=list.get(list.size()-1).getName();
        volume+=list.get(list.size()-1).getVolume();
        apiService.setCookie(request,response,"goodsVolume",volume);
        apiService.setCookie(request,response,"goodsName",name);
        return commodityService.list_volume();
    }
    @RequestMapping(value = "/Commodities_list_gross",method = RequestMethod.GET)
    public List<Commodity> Commodities_list_gross(HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        List<Commodity>list=commodityService.list_num();
        String sell="";
        String name="";
        for(int i=0;i<list.size()-1;i++){
            sell+=list.get(i).getGross()+"#";
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        sell+=list.get(list.size()-1).getGross();
        apiService.setCookie(request,response,"goodsName",name);
        apiService.setCookie(request,response,"goodsGross",sell);
        return commodityService.list_gross();
    }

   @RequestMapping(value = "/Commodities_SearchById",method = RequestMethod.GET)
   public String searchById(@RequestParam(value = "num",defaultValue = "0") int num,Model model){
       if (num==0)
           return "Commodities_SearchById";
       if(commodityService.listAll(num).isEmpty())
           return "Commodities_SearchById";
       Commodity commodity=  commodityService.listAll(num).get(0);
       model.addAttribute(commodity);
       return "commodity";
   }

    @RequestMapping(value = "/Seller_Commodities_SearchById",method = RequestMethod.GET)
    public String seller_searchById(@RequestParam(value = "num",defaultValue = "0") int num,Model model){
        if (num==0)
            return "Seller_Commodities_SearchById";
        if(commodityService.listAll(num).isEmpty())
            return "Seller_Commodities_SearchById";
        Commodity commodity=  commodityService.listAll(num).get(0);
        model.addAttribute(commodity);
        return "commodity_Seller";
    }

    @RequestMapping(value = "/Buyer_Commodities_SearchById",method = RequestMethod.GET)
    public String buyer_searchById(@RequestParam(value = "num",defaultValue = "0") int num,Model model){
        if (num==0)
            return "Buyer_Commodities_SearchById";
        if(commodityService.listAll(num).isEmpty())
            return "Buyer_Commodities_SearchById";
        Commodity commodity=  commodityService.listAll(num).get(0);
        model.addAttribute(commodity);
        return "commodity_Buyer";
    }

    @RequestMapping(value = "/Seller_Commodities_add",method = RequestMethod.GET)
    public  String Seller_Commodities_add(@RequestParam(value = "num",defaultValue = "0")int num,@RequestParam(value = "sell",defaultValue = "0")int sell){
        if(num==0)
            return "Seller_Commodities_add";
        if(commodityService.listAll(num).isEmpty())
            return "Seller_Commodities_add";
        Commodity commodity=commodityService.listAll(num).get(0);
        commodity.setSell(commodity.getSell()+sell);
        commodity.setVolume();
        Ware ware=wareService.listAll(num).get(0);
        commodity.setRemain(ware.getTotal_stock()-ware.getTotal_sell());
        commodity.setGross();
        commodityService.amend_num(num,commodity);
        ware.setTotal_sell(ware.getTotal_sell()+sell);
        ware.setTotal_cost();
        ware.setTotal_volume();
        ware.setTotal_benefit();
        wareService.amend_num(num,ware);
        return "Seller_Commodities_add";
    }

    @RequestMapping(value = "/Buyer_Commodities_add",method = RequestMethod.GET)
    public  String Buyer_Commodities_add(@RequestParam(value = "num",defaultValue = "-2")int num,@RequestParam(value = "stock",defaultValue = "0")int stock){
        if(num==-2)
            return "Buyer_Commodities_add";
        if(commodityService.listAll(num).isEmpty()) {
            return "Buyer_Commodities_add";
        }
        Commodity commodity=commodityService.listAll(num).get(0);
        commodity.setStock(commodity.getStock()+stock);
        commodity.setVolume();
        Ware ware=wareService.listAll(commodity.getNum()).get(0);
        commodity.setRemain(ware.getTotal_stock()-ware.getTotal_sell());
        commodity.setGross();
        commodityService.amend_num(num,commodity);

        ware.setTotal_stock(ware.getTotal_stock()+stock);
        ware.setTotal_cost();
        ware.setTotal_volume();
        ware.setTotal_benefit();
        wareService.amend_num(num,ware);
        return "Seller_Commodities_add";
    }
}
