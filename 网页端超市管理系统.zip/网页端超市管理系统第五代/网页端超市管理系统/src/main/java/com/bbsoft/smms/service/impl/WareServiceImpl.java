package com.bbsoft.smms.service.impl;

import com.bbsoft.smms.domain.Ware;
import com.bbsoft.smms.mapper.WareMapper;
import com.bbsoft.smms.service.WareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WareServiceImpl implements WareService {

    private final WareMapper wareMapper;

    @Autowired
    public WareServiceImpl(WareMapper wareMapper) {
        this.wareMapper = wareMapper;
    }

    @Override
    public  List<Ware>listAll(int num){return wareMapper.listAll(num);}

    @Override
    public void delete_all(){ wareMapper.delete_all();}                                      //prepare insert

    @Override
    public List<Ware> list_num() {
        return wareMapper.list_num();
    }
    @Override
    public List<Ware> list_volume() {return wareMapper.list_volume();}                 //information_display
    @Override
    public List<Ware> list_gross() {return wareMapper.list_gross();}

    @Override
    public void add(Ware ware) {
        wareMapper.add(ware);
    }
    @Override
    public void delete_num(int num) { wareMapper.delete_num(num); }
    @Override
    public  void delete_name(String name) { wareMapper.delete_name(name);}                     //Update
    @Override
    public void amend_num(int number,Ware ware) { wareMapper.amend_num(number,ware);}

    @Override
    public List<Ware> search_num(int num){return wareMapper.search_num(num);}
    @Override
    public List<Ware> search_name(String name) {return wareMapper.search_name(name);}     //sales_statistics
}
