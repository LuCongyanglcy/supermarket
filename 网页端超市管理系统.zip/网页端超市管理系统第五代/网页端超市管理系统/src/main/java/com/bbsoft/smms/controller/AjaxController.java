package com.bbsoft.smms.controller;


import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.service.CommodityService;
import com.bbsoft.smms.service.WareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin
public class AjaxController {

    @Autowired
    CommodityService commodityService;
    @Autowired
    WareService wareService;

    @PostMapping("goodsName")
    public String goods_name(){
        List<Commodity>list=commodityService.list_num();
        String name="";
        for(int i=0;i<list.size()-1;i++){
            name+=list.get(i).getName()+"#";
        }
        name+=list.get(list.size()-1).getName();
        System.out.println(name);
        return name;
    }

}
