package com.bbsoft.smms.service.impl;

import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.mapper.CommodityMapper;
import com.bbsoft.smms.service.CommodityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommodityServiceImpl implements CommodityService {

    private final CommodityMapper commodityMapper;

    @Autowired
    public CommodityServiceImpl(CommodityMapper commodityMapper) {
        this.commodityMapper = commodityMapper;
    }

    @Override
    public  List<Commodity>listAll(int num){return commodityMapper.listAll(num);}

    @Override
    public void delete_all(){
        commodityMapper.delete_all();}                                      //prepare insert

    @Override
    public List<Commodity> list_num() {
        return commodityMapper.list_num();
    }
    @Override
    public List<Commodity> list_volume() {return commodityMapper.list_volume();}                 //information_display
    @Override
    public List<Commodity> list_gross() {return commodityMapper.list_gross();}

    @Override
    public void add(Commodity commodity) {
        commodityMapper.add(commodity);
    }
    @Override
    public void delete_num(int num) { commodityMapper.delete_num(num); }
    @Override
    public void amend_num(int number,Commodity commodity) {
        commodityMapper.amend_num(number,commodity);}

    @Override
    public List<Commodity> search_num(int num){return commodityMapper.search_num(num);}
    @Override
    public List<Commodity> search_name(String name) {return commodityMapper.search_name(name);}     //sales_statistics
    @Override
    public List<Commodity> kind_Search(String s) {return commodityMapper.kind_Search(s);}

}
