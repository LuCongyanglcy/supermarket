package com.bbsoft.smms.service.impl;

import com.bbsoft.smms.domain.User;
import com.bbsoft.smms.mapper.UserMapper;
import com.bbsoft.smms.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{

    private final UserMapper userMapper;

    @Autowired
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }


    @Override
    public List<User>index(String  username){return userMapper.index(username);}

    @Override
    public List<User> listAll(){return userMapper.listAll();}

    @Override
    public List<User>searchId(int id){return userMapper.searchId(id);}

    @Override
    public void amendId(int id,User user){userMapper.amendId(id,user);}

    @Override
    public List<User> verify(User user) {
        return userMapper.verify(user);
    }


    @Override
    public List<User> verify_protection(User user) { return userMapper.verify_protection(user);}


    @Override
    public void new_user(User user) { userMapper.new_user(user); }

    @Override
    public void delete(int id) { userMapper.delete(id); }

}
