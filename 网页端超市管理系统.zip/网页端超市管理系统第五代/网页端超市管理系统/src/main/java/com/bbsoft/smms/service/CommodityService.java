package com.bbsoft.smms.service;

import com.bbsoft.smms.domain.Commodity;

import java.util.List;

public interface CommodityService {
    void delete_all();               //prepare insert

    List<Commodity>listAll(int num);

    List<Commodity> list_num();

    List<Commodity> list_volume();              //Information display

    List<Commodity> list_gross();


    void add(Commodity commodity);

    void delete_num(int num);

                                                      //Update
    void amend_num(int number, Commodity commodity);



    List<Commodity> search_num(int num);

    List<Commodity> search_name(String name);                 //sales_statistics

    List<Commodity> kind_Search(String s);

}
