package com.bbsoft.smms.domain;


import com.bbsoft.smms.service.CommodityService;
import com.bbsoft.smms.service.WareService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class Commodity {
    
    private int num;
    private String name;
    private String kind;
    private float bid;
    private float price;
    private int stock;  //进货量
    private int sell;
    private float volume;
    private int remain;
    private float gross;

    public Commodity(){}

    public Commodity(int num, String name, String kind, float bid, float price, int stock, int sell, float volume, int remain, float gross) {
        this.num=num;
        this.name = name;
        this.kind=kind;
        this.bid=bid;
        this.price=price;
        this.stock=stock;
        this.sell=sell;
        this.volume=volume;
        this.remain=remain;
        this.gross=gross;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public float getBid() {
        return bid;
    }

    public void setBid(float bid) {
        this.bid = bid;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getSell() {
        return sell;
    }

    public void setSell(int sell) {
        this.sell = sell;
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume() {
        this.volume = this.price*this.sell ;
    }

    public int getRemain() {
        return remain;
    }

    public void setRemain(int num) {
        this.remain=num;
    }

    public float getGross() {
        return gross;
    }

    public void setGross() {
        this.gross = this.volume-this.sell*this.bid;
    }

    @Override
    public String toString() {
        return String.format("编号%d, name:%s, kind:%s,bid:%f,price:%f,进货量%d,销售量：%d,volume:%f,remain:%d,gross:%f",num,name,kind,bid,price,stock,sell,volume,remain,gross);
    }
}
