package com.bbsoft.smms.controller;

import com.bbsoft.smms.domain.Commodity;
import com.bbsoft.smms.service.CommodityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TestController {

    @Autowired
    CommodityService commodityService;

    @RequestMapping(value = "/aaa",method = RequestMethod.GET)
    public List<Commodity> bbbb(){
        return commodityService.list_num();
    }
}
