package com.bbsoft.smms.mapper;

import com.bbsoft.smms.domain.Ware;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface WareMapper {

    void delete_all();               //prepare insert

    List<Ware>listAll(int num);

    List<Ware> list_num();

    List<Ware> list_volume();              //Information display

    List<Ware> list_gross();


    void add(Ware ware);

    void delete_num(int num);

    void delete_name(String name);

    void amend_num(@Param("num") int number, @Param("ware") Ware ware);



    List<Ware> search_num(int num);

    List<Ware> search_name(String name);          //sales_statistics


    //int returnRecordNum();
}
