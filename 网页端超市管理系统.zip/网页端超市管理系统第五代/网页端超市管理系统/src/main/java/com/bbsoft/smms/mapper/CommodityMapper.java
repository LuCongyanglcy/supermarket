package com.bbsoft.smms.mapper;

import com.bbsoft.smms.domain.Commodity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CommodityMapper {
    void delete_all();               //prepare insert

    List<Commodity>listAll(int num);

    List<Commodity> list_num();

    List<Commodity> list_volume();              //Information display

    List<Commodity> list_gross();


    void add(Commodity commodity);

    void delete_num(int num);

                                                 //Update
    void amend_num(@Param("num") int number, @Param("commodity") Commodity commodity);




    List<Commodity> search_num(int num);

    List<Commodity> search_name(String name);                 //sales_statistics

    List<Commodity> kind_Search(String s);

    //int returnRecordNum();
}
