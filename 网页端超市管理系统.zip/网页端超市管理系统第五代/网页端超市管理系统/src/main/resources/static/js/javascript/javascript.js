var goodName="null";

function goodsName() {
    $(document).ready(function () {
        $.post("/goodsName",{
            contentType:"application/x-www-form-urlencode;charset=utf-8",
            async: true
        }, function (data/*, status*/) {
            goodName=data;
        });
    });
    //});
}





















































function successfully() {
    alert("恭喜您：操作成功！");
}

function setCookie(cname,cvalue){
    document.cookie = cname+"="+cvalue;
}

function getCookie(cname){
    let ca=new Array();
    ca = divideYourAnswerLittles(document.cookie,";");
    let na="";
    let n="";
    for(let i=0;i<ca.length;i++){
        na=String(ca[i]);
        if(na.substring(0,na.indexOf("=")).trim()==cname) {
            n= na.substring(ca[i].indexOf("=")+1, ca[i].length);
            break;
        }
    }
    return n;
}
function sleep(d){
    for(let t = Date.now();Date.now() - t <= d;);
}

function downloadFile(formId) {
    var upl = document.getElementById(formId);
    upl.submit();
}
function divideYourAnswerLittle(stringList) {
    let b = " ,，$；+";
    return divideYourAnswerLittles(stringList,b);
}

function panand(b, a) {
    for (let i = 0; i < b.length; i++) {
        if (b.charAt(i) == a) return -1;
    }
    return 1;
}

function divideYourAnswerLittles(stringList, symbol) {
    let strings=new Array();
    let c = "";
    for (let j = 0; j < stringList.length; j++) {
        if (panand(symbol, stringList.charAt(j))==1)
            c += stringList.charAt(j);
        if (panand(symbol, stringList.charAt(j))==-1 || (j + 1) == stringList.length) {
            strings.push(c);
            c = "";
        }
    }
    return strings;
}