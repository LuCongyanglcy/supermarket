TODO:1.添加更多窗体
TODO:2.完善商品记录，并修改sql中的表
NOTES:
1.静态文件都放在/static文件夹里
2.数据库操作在mapper文件夹里，设计接口时注意mapper, service, serviceImpl这3者的一致性
3.代码中有必要的地方记得加注释，未完成的地方记得加TODO注释来标注还需完成的工作
4.开始写代码前先确认TODO,并查看README.txt